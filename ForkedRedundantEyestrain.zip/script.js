function changeStyle() {
var combo = document.getElementById("styleCombo");
var selectedValue = combo.value;
var div = document.getElementById("myDiv");

if (selectedValue === "style1"){
div.className = "style1"
}
else if (selectedValue === "style2"){
div.className = "style2"
}
else if (selectedValue === "style3"){
div.className = "style3"
}

}